<?php include "councillorDashboardMainLogic.php"; ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Councillor Dashboard</title>
    <link rel="stylesheet" href="publicFaultBoard.css"> 
    <link rel="stylesheet" href="councillorDashboard.css">
    <link rel="stylesheet" href="councillorDashboardSideBar.css">

    <style>
        
    </style>
</head>
<body>
    <div class="dashboardContainer">

        <!--###### Navidation/SideBar Bar ##############-->
        
         <input type="checkbox" id="sidebarToggle">
        <label for="sidebarToggle" class="hamburger">
            <span></span><span></span><span></span>
        </label>
        <aside class="sidebar">
            
            <nav class="navigation">
                <img src="MakanaLogo.svg" height="150" width="150" alt="M-link logo">
                
                <ul>
                    <li><a href="#home-section">Home</a></li>
                    <li><a href="#appointments-section">Appointments</a></li>
                    <li><a href="#patient-details-section">Patients</a></li>
                    <li><a href="#schedule-section">Schedule</a></li>
                </ul>
            </nav>
            <div class="sidebar-footer">
                <button class="logout-btn"><a href="DoctorLoginPage.html">Logout</a></button>
            </div>
        </aside>

        <!-- ################################################### -->
        
        <main class="content">
            <header class="dashboardHeader">
                <h1>Ward Overview</h1>
                <p>Real-time infrastructure analytics and fault management core system.</p>
            </header>

            <!-- kpi => Key perfomance indicator  -->
            <section class="kpiGrid">
                <div class="kpiCard activeFaults">
                    <h4>Active Faults</h4>
                    <p class="metric">14</p>
                </div>
                <div class="kpiCard inProgress">
                    <h4>In Progress</h4>
                    <p class="metric">6</p>
                </div>
                <div class="kpiCard resolvedCount">
                    <h4>Resolved This Month</h4>
                    <p class="metric">38</p>
                </div>
            </section>

            <section class="mainWorkspace">
                <div class="mapPanel">
                    <h3 class="panelTitle">Ward Spatial Fault Distribution</h3>
                    <div id="grahamstownMap"></div>
                </div>
                
                <div class="chartPanel">
                    <h3 class="panelTitle">Ticket Composition</h3>
                    <div class="chartWrapper">
                        <canvas id="categoryChart" 
                                data-categories="<?php echo htmlspecialchars($jsonCategories); ?>"
                                data-counts="<?php echo htmlspecialchars($jsonCounts); ?>">
                        </canvas>
                    </div>
                </div>
            </section>

            <section class="tableRepository">
                <h3 class="registryTitle">Detailed Incident Registry</h3>
                
                <div class="searchFilterWrapper">
                    <div class="searchBox">
                        <input type="text" id="tableSearch" placeholder="Search by street or description...">
                        <span class="searchIcon">
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#666" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <circle cx="11" cy="11" r="8"></circle>
                                <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
                            </svg>
                        </span>
                    </div>
                    <div class="filterDropdown">
                        <select id="categoryFilter">
                            <option value="">All Categories</option>
                            <option value="Roads & Streets">Roads & Streets</option>
                            <option value="Water & Sewer">Water & Sewer</option>
                            <option value="Electricity & Lighting">Electricity & Lighting</option>
                            <option value="Parks & Recreation">Parks & Recreation</option>
                        </select>
                    </div>
                    <div class="filterDropdown">
                        <select id="statusFilter">
                            <option value="">All Statuses</option>
                            <option value="Logged">Logged</option>
                            <option value="Reported">Reported</option>
                            <option value="Resolved">Resolved</option>
                        </select>
                    </div>
                </div>

                <table class="dataTable">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Category</th>
                            <th>Location / Description</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody id="ticketTableBody">
                        <?php if (count($tickets) > 0): ?>
                            <?php foreach ($tickets as $ticket): 
                                $statusClass = '';
                                switch (strtolower($ticket['status'])) {
                                    case 'logged':   $statusClass = 'badge logged'; break;
                                    case 'reported': $statusClass = 'badge in-progress'; break;
                                    case 'resolved': $statusClass = 'badge resolved'; break;
                                    default:         $statusClass = 'badge'; break;
                                }
                                $displayStatus = ucfirst($ticket['status']);
                                $displayId = '#TK-' . str_pad($ticket['id'], 3, '0', STR_PAD_LEFT);
                            ?>
                            <tr data-ticket-id="<?= $ticket['id'] ?>">
                                <td class="ticketId"><?= $displayId ?></td>
                                <td><?= htmlspecialchars($ticket['category']) ?></td>
                                <td><?= htmlspecialchars($ticket['location']) ?><br><small style="color:#666;"><?= htmlspecialchars($ticket['description']) ?></small></td>
                                <td><span class="<?= $statusClass ?>"><?= $displayStatus ?></span></td>
                                <td>
                                    <!-- Status Dropdown -->
                                    <select class="status-select" data-ticket-id="<?= $ticket['id'] ?>">
                                        <option value="Logged"   <?= $ticket['status'] == 'Logged'   ? 'selected' : '' ?>>Logged</option>
                                        <option value="Reported" <?= $ticket['status'] == 'Reported' ? 'selected' : '' ?>>Reported</option>
                                        <option value="Resolved" <?= $ticket['status'] == 'Resolved' ? 'selected' : '' ?>>Resolved</option>
                                    </select>
                                    <!-- Add Note -->
                                    <input type="text" class="note-input" placeholder="Add note..." data-ticket-id="<?= $ticket['id'] ?>">
                                    <button class="note-btn" data-ticket-id="<?= $ticket['id'] ?>">➕</button>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr><td colspan="5" style="text-align:center; padding:30px;">No tickets found for your ward.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </section>
        </main>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="councillorDashboard.js" defer></script>

</body>
</html>