<?php 
    include "connection.php";
    //#################### VISUALIZATION #######################################

                                        //Query the count of unresolved tickets grouped by the category

    // ####################################### SAMPLE DATA ######################################################
    // WE ARE NOT PULLING FORM THE DATABASE YET
    $tickets = [
    [
        'id' => 104,
        'category' => 'Water & Sewer',
        'description' => 'Burst pipe on African St',
        'location' => 'African Street (Near Cathedral)',
        'status' => 'Reported'
    ],
    [
        'id' => 112,
        'category' => 'Roads & Streets',
        'description' => 'Pothole on High St',
        'location' => 'High Street (Opposite Court)',
        'status' => 'Logged'
    ],
    [
        'id' => 121,
        'category' => 'Electricity & Lighting',
        'description' => 'Street light out at intersection',
        'location' => 'Hill & Main',
        'status' => 'Reported'
    ],
    [
        'id' => 135,
        'category' => 'Water & Sewer',
        'description' => 'Sewage blockage',
        'location' => 'Bathurst St, behind Spar',
        'status' => 'Logged'
    ],
    [
        'id' => 140,
        'category' => 'Parks & Recreation',
        'description' => 'Broken playground equipment',
        'location' => 'Highland Park',
        'status' => 'Resolved'
    ]
];

// ################################################################################################

    $chartQuery = "SELECT category, count(*) as ticketCount
                 FROM faulttickets
                 WHERE LOWER(status) != 'resolved'
                 GROUP BY category
                 ";
    
    $chartResults = $conn->query($chartQuery);

    $categories = [];
    $counts = [];

    if($chartResults && $chartResults -> num_rows > 0){
        while($row = $chartResults->fetch_assoc()){
            $categories[] = $row['category'];
            $counts[] = (int)$row['ticketCount'];
        }
    }

    $jsonCategories = json_encode($categories);
    $jsonCounts = json_encode($counts);
    
?>