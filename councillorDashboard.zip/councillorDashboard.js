/* ####### DASHBOARD ANALYTICAL ENGINE ########## */

document.addEventListener("DOMContentLoaded", () => {
    const canvasElement = document.getElementById("categoryChart");

    if(!canvasElement){ return;}                     // check if the chart context template exists on an active layout
                                                    // Extract and parse datasets directly from DOM attributes
    const rawCategories = canvasElement.getAttribute("data-categories");
    const rawCounts = canvasElement.getAttribute("data-counts");

                                                    //Parse the JSON strings securely into real JavaScript arrays
    const chartLabels = rawCategories ? JSON.parse(rawCategories) : [];
    const chartData = rawCounts ? JSON.parse(rawCounts) : [];

                                                    // display placeholder values if no active data exists
    const labelsToRender = chartLabels.length > 0 ? chartLabels : ["No Active Issues"];
    const dataToRender = chartData.length > 0 ? chartData : [1];

    const backgroundColors = chartLabels.length > 0 
        ? ['#c62828', '#5b510f', '#0288d1', '#7b1fa2', '#f57c00'] // Master color theme map
        : ['#e0e0e0'];                                                      // Gray fallback ring

                                                    // graphic rendering target context map
    const ctx = canvasElement.getContext('2d');
                                                    // Initializing the chart engine definition
    new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: labelsToRender,
            datasets: [{
                data: dataToRender,
                backgroundColor: backgroundColors,
                borderWidth: 2,
                borderColor: '#ffffff'
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: {
                        boxWidth: 12,
                        font: {
                            family: 'sans-serif',
                            size: 13
                        },
                        padding: 15
                    }
                },
                tooltip: {
                    enabled: chartLabels.length > 0
                }
            },
            cutout: '70%'
        }
    });

});