const stars = document.querySelectorAll(".star-rating span"); 
let rating = 0; 

stars.forEach(star=>{
    star.addEventListener("click", function(){
        rating = this.dataset.value;
        stars.forEach(s=>s.classList.remove("active"));
        for (let i=0 ; i<rating ; i++){
            stars[i].classList.add("active");
        }
    });
});
document.getElementById("reviewForm").addEventListener("submit", function(e){
    e.preventDefault();
    let review = document.getElementById("review").value.trim(); 
    let constant = document.getElementById("consent").checked;
    if (review==""){
        alert("Please write a review"); 
        return; 
    }
    if(rating==0){
        alert("Please select a rating"); 
        return; 
    }
    if (!constant){
        alert("Please give a consent before submitting."); 
        return; 
    }
    document.getElementById("success").innerHTML = "Thank you for you feeback!"; 
    this.reset(); 
    stars.forEach(s=>s.classList.remove("active")); 
    rating=0; 
}); 