
// ADD COUNCILLOR MODAL


function openModal() {
    document.getElementById("councillorModal").classList.add("show");
}

function closeModal() {
    document.getElementById("councillorModal").classList.remove("show");
}



// ACTION MENU


function toggleMenu(button) {

    const menu = button.nextElementSibling;

    document.querySelectorAll(".action-menu").forEach(function(item) {

        if (item !== menu) {
            item.classList.remove("show");
        }

    });

    menu.classList.toggle("show");
}


document.addEventListener("click", function(event) {

    if (!event.target.closest(".action-button")) {

        document.querySelectorAll(".action-menu").forEach(function(menu) {
            menu.classList.remove("show");
        });

    }

});



// SEARCH


function searchCouncillors() {

    const input =
        document.getElementById("searchInput").value.toLowerCase();

    const rows =
        document.querySelectorAll("#councillorTable tbody tr");

    rows.forEach(function(row) {

        const text = row.innerText.toLowerCase();

        row.style.display =
            text.includes(input) ? "" : "none";

    });

}


// ================================
// FILTER
// ================================

function filterTable() {

    const ward =
        document.getElementById("wardFilter").value.toLowerCase();

    const status =
        document.getElementById("statusFilter").value.toLowerCase();

    const rows =
        document.querySelectorAll("#councillorTable tbody tr");

    rows.forEach(function(row) {

        const text = row.innerText.toLowerCase();

        const matchesWard =
            ward === "" || text.includes(ward);

        const matchesStatus =
            status === "" || text.includes(status);

        row.style.display =
            matchesWard && matchesStatus
                ? ""
                : "none";

    });

}

// ADD COUNCILLOR


document.addEventListener("DOMContentLoaded", function() {

    const form = document.querySelector("#councillorModal form");

    form.addEventListener("submit", function(event) {

        event.preventDefault();

        // Get form values
        const firstName =
            form.querySelector('input[placeholder="Enter first name"]').value.trim();

        const surname =
            form.querySelector('input[placeholder="Enter surname"]').value.trim();

        const email =
            form.querySelector('input[placeholder="Enter email address"]').value.trim();

        const phone =
            form.querySelector('input[placeholder="Enter phone number"]').value.trim();

        const role =
            form.querySelectorAll("select")[0].value;

        const status =
            form.querySelectorAll("select")[1].value;

        const ward =
            form.querySelectorAll("select")[2].value;


        // ================================
        // VALIDATION
        // ================================

        if (
            firstName === "" ||
            surname === "" ||
            email === "" ||
            phone === "" ||
            ward === ""
        ) {

            alert("Please complete all required fields.");

            return;
        }


        // ================================
        // CREATE INITIALS
        // ================================

        const initials =
            firstName.charAt(0).toUpperCase() +
            surname.charAt(0).toUpperCase();


        // ================================
        // CREATE NEW TABLE ROW
        // ================================

        const tableBody =
            document.querySelector("#councillorTable tbody");

        const newRow =
            document.createElement("tr");

        newRow.innerHTML = `

            <td>

                <div class="councillor-info">

                    <div class="avatar">
                        ${initials}
                    </div>

                    <div>

                        <strong>
                            ${firstName} ${surname}
                        </strong>

                        <small>
                            ${email}
                        </small>

                    </div>

                </div>

            </td>


            <td>
                ${phone}
            </td>


            <td>

                <span class="ward-badge">
                    ${ward}
                </span>

            </td>


            <td>
                ${role}
            </td>


            <td>

                <span class="status ${status.toLowerCase()}">
                    ${status}
                </span>

            </td>


            <td>

                <button
                    class="action-button"
                    onclick="toggleMenu(this)"
                >
                    ⋮
                </button>

                <div class="action-menu">

                    <button>
                        View Profile
                    </button>

                    <button>
                        Edit
                    </button>

                    <button>
                        Change Ward
                    </button>

                    <button class="danger">
                        Suspend Account
                    </button>

                </div>

            </td>

        `;


        tableBody.appendChild(newRow);


        
        // UPDATE COUNTER
        

        updateCouncillorCount();


        
        // RESET FORM
        

        form.reset();


    
        // CLOSE MODAL
        

        closeModal();


        
        // SUCCESS MESSAGE
        

        alert(
            firstName + " " + surname +
            " has been added successfully."
        );

    });

});


// 
// UPDATE COUNTER
// 

function updateCouncillorCount() {

    const rows =
        document.querySelectorAll("#councillorTable tbody tr");

    const counter =
        document.querySelector(".total-count");

    counter.textContent =
        rows.length + " Councillors";

}