//USE mlink_db;

CREATE TABLE users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,

    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,

    email VARCHAR(150) NOT NULL UNIQUE,
    phone VARCHAR(20) NOT NULL,

    password VARCHAR(255) NULL,

    role ENUM(
        'Resident',
        'Councillor',
        'Admin',
        'Communication Officer'
    ) NOT NULL DEFAULT 'Resident',

    status ENUM(
        'Active',
        'Inactive',
        'Suspended'
    ) NOT NULL DEFAULT 'Active',

    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);