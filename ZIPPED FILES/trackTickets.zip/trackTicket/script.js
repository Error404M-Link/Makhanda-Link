google.charts.load('current', {packages: ['corechart']});
google.charts.setOnLoadCallback(drawChart);

function drawChart() {
  var data = google.visualization.arrayToDataTable([
    ['Status', 'Tickets'],
    ['Open', 12],
    ['In Progress', 8],
    ['Closed', 15]
  ]);

  var options = {
    title: 'Tickets by Status',
    pieHole: 0.4,
    colors: ['#ff4d4d', '#ffc107', '#28a745']
  };

  var chart = new google.visualization.PieChart(document.getElementById('ticketChart'));
  chart.draw(data, options);
}